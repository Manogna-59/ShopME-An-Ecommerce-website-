ShopMe---A Single Page E-Commerce application for sustainable fashion of Clothing--

--UI/UX design----

1.This application provides access to different catergories in clothing store and your regular wardobe.
2.It directs to various filters--login details
                              --women
                              --men
                              --our products
                              --categories
                              --history
                              --reviews
                              --cart items
                              --contact info,etc 
3.This is a completely responsive website built without using any readymade codes.
                              
                            
  
  Technologies used :HTML,CSS,Javascript
  



  ---Steps to run this application--



  1.Open this folder in Visual Studio 
  2.Use live server to run the application

  (OR)

  1.Click on the 'indx' file from the folder and the page gets displayed 
  2.You can traverse various options and filters followed by search,cart,and,user icons

  --For more clear view you can also go through screenshots provided in the folder--
  